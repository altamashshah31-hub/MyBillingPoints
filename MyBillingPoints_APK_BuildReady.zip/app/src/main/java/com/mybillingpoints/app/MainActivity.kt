package com.mybillingpoints.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mybillingpoints.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class Draft(val product:String,val qty:Double,val rate:Double)

class VM(private val db:AppDatabase):ViewModel(){
    val bills=db.bills().all()
    val products=db.products().all()
    private val m=SimpleDateFormat("yyyy-MM",Locale.US).format(Date())
    val amount=db.bills().monthAmount(m)
    val count=db.bills().monthBills(m)
    val qty=db.bills().monthQty(m)

    fun addProduct(n:String,c:String,mo:String)=viewModelScope.launch{
        if(n.isNotBlank()) db.products().insert(Product(name=n,category=c,model=mo))
    }
    fun addBill(no:String,cust:String,rows:List<Draft>)=viewModelScope.launch{
        if(no.isBlank()||rows.isEmpty()) return@launch
        val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
        val total=rows.sumOf{it.qty*it.rate}
        val id=db.bills().insert(Bill(billNo=no,date=d,customer=cust,totalAmount=total))
        db.bills().insertItems(rows.map{BillItem(billId=id,productName=it.product,quantity=it.qty,rate=it.rate,amount=it.qty*it.rate)})
    }
    fun deleteBill(b:Bill)=viewModelScope.launch{db.bills().delete(b)}
}

class MainActivity:ComponentActivity(){
    override fun onCreate(s:Bundle?){
        super.onCreate(s)
        val db=AppDatabase.get(this)
        setContent{
            val vm=remember{ViewModelProvider(this,object:ViewModelProvider.Factory{
                override fun <T:ViewModel> create(c:Class<T>):T=VM(db) as T
            })[VM::class.java]}
            App(vm)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(vm:VM){
    var tab by remember{mutableIntStateOf(0)}
    var add by remember{mutableStateOf(false)}
    val names=listOf("Dashboard","Bills","Products","Reports","Settings")
    val mr=listOf("डॅशबोर्ड","बिले","उत्पादने","रिपोर्ट्स","सेटिंग्स")
    Scaffold(
        topBar={TopAppBar(title={Text("${names[tab]} / ${mr[tab]}")})},
        bottomBar={NavigationBar{
            listOf(Icons.Default.Home,Icons.Default.ReceiptLong,Icons.Default.Inventory2,Icons.Default.BarChart,Icons.Default.Settings)
                .forEachIndexed{i,ic->NavigationBarItem(i==tab,{tab=i},{Icon(ic,null)},label={Text(names[i])})}
        }},
        floatingActionButton={if(tab==1)FloatingActionButton({add=true}){Icon(Icons.Default.Add,"Add")}}
    ){p->Box(Modifier.padding(p).fillMaxSize()){
        when(tab){0->Dash(vm);1->Bills(vm);2->Products(vm);3->Reports(vm);4->Settings()}
    }}
    if(add) BillDialog(vm){add=false}
}

@Composable fun Dash(vm:VM){
    val a by vm.amount.collectAsState(0.0); val c by vm.count.collectAsState(0); val q by vm.qty.collectAsState(0.0)
    LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("My Billing Points",style=MaterialTheme.typography.headlineMedium)}
        item{Stat("Monthly Billing / मासिक Billing","₹%.2f".format(a))}
        item{Stat("Bills / बिले",c.toString())}
        item{Stat("Quantity / प्रमाण",q.toString())}
    }
}
@Composable fun Stat(l:String,v:String)=Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(l);Text(v,style=MaterialTheme.typography.titleLarge)}}

@Composable fun Bills(vm:VM){
    val bs by vm.bills.collectAsState(emptyList())
    LazyColumn(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        items(bs){b->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp)){
            Column(Modifier.weight(1f)){Text("Bill ${b.billNo}",style=MaterialTheme.typography.titleMedium);Text("${b.date} • ${b.customer.ifBlank{"Walk-in"}}");Text("₹%.2f".format(b.totalAmount))}
            IconButton({vm.deleteBill(b)}){Icon(Icons.Default.Delete,"Delete")}
        }}}
    }
}

@Composable fun Products(vm:VM){
    val ps by vm.products.collectAsState(emptyList())
    var n by remember{mutableStateOf("")};var c by remember{mutableStateOf("")};var m by remember{mutableStateOf("")}
    Column(Modifier.padding(16.dp)){
        OutlinedTextField(n,{n=it},label={Text("Product / उत्पादन")},Modifier.fillMaxWidth())
        OutlinedTextField(c,{c=it},label={Text("Category / प्रकार")},Modifier.fillMaxWidth())
        OutlinedTextField(m,{m=it},label={Text("Model")},Modifier.fillMaxWidth())
        Button({vm.addProduct(n,c,m);n="";c="";m=""},Modifier.fillMaxWidth()){Text("Save / जतन")}
        LazyColumn{items(ps){Text("${it.name} • ${it.model}",Modifier.padding(10.dp))}}
    }
}
@Composable fun Reports(vm:VM){
    val a by vm.amount.collectAsState(0.0)
    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Reports / रिपोर्ट्स",style=MaterialTheme.typography.headlineSmall)
        Text("Current month total: ₹%.2f".format(a))
        Button({},Modifier.fillMaxWidth()){Text("Export Excel")}
        Button({},Modifier.fillMaxWidth()){Text("Export PDF")}
    }
}
@Composable fun Settings(){
    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Settings / सेटिंग्स",style=MaterialTheme.typography.headlineSmall)
        Button({},Modifier.fillMaxWidth()){Text("PIN Lock / PIN लॉक")}
        Button({},Modifier.fillMaxWidth()){Text("Google Drive Backup")}
        Button({},Modifier.fillMaxWidth()){Text("Restore from Drive")}
    }
}
@Composable fun BillDialog(vm:VM,close:()->Unit){
    var no by remember{mutableStateOf("")};var cust by remember{mutableStateOf("")};var p by remember{mutableStateOf("")}
    var q by remember{mutableStateOf("1")};var r by remember{mutableStateOf("")};var rows by remember{mutableStateOf(listOf<Draft>())}
    AlertDialog(onDismissRequest=close,title={Text("New Bill / नवीन बिल")},text={
        Column(verticalArrangement=Arrangement.spacedBy(5.dp)){
            OutlinedTextField(no,{no=it},label={Text("Bill No.")})
            OutlinedTextField(cust,{cust=it},label={Text("Customer / ग्राहक")})
            OutlinedTextField(p,{p=it},label={Text("Product / उत्पादन")})
            OutlinedTextField(q,{q=it},label={Text("Quantity / प्रमाण")})
            OutlinedTextField(r,{r=it},label={Text("Rate / दर")})
            Button({val x=q.toDoubleOrNull()?:0.0;val y=r.toDoubleOrNull()?:0.0;if(p.isNotBlank()&&x>0)rows=rows+Draft(p,x,y)}){Text("Add Product")}
            rows.forEach{Text("${it.product}: ${it.qty} × ₹${it.rate} = ₹${it.qty*it.rate}")}
        }
    },confirmButton={Button({vm.addBill(no,cust,rows);close()}){Text("Save / जतन")}},
      dismissButton={TextButton(close){Text("Cancel")}})
}

package com.mybillingpoints.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="products")
data class Product(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val category:String="",val model:String="",val unit:String="PCS")

@Entity(tableName="bills")
data class Bill(@PrimaryKey(autoGenerate=true) val id:Long=0,val billNo:String,val date:String,val customer:String="",val totalAmount:Double=0.0)

@Entity(tableName="bill_items",foreignKeys=[ForeignKey(entity=Bill::class,parentColumns=["id"],childColumns=["billId"],onDelete=ForeignKey.CASCADE)])
data class BillItem(@PrimaryKey(autoGenerate=true) val id:Long=0,val billId:Long,val productName:String,val quantity:Double,val rate:Double,val amount:Double)

@Dao interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name") fun all():Flow<List<Product>>
    @Insert suspend fun insert(p:Product)
}
@Dao interface BillDao {
    @Query("SELECT * FROM bills ORDER BY date DESC,id DESC") fun all():Flow<List<Bill>>
    @Insert suspend fun insert(b:Bill):Long
    @Delete suspend fun delete(b:Bill)
    @Insert suspend fun insertItems(items:List<BillItem>)
    @Query("SELECT COALESCE(SUM(totalAmount),0) FROM bills WHERE substr(date,1,7)=:m") fun monthAmount(m:String):Flow<Double>
    @Query("SELECT COUNT(*) FROM bills WHERE substr(date,1,7)=:m") fun monthBills(m:String):Flow<Int>
    @Query("SELECT COALESCE(SUM(quantity),0) FROM bill_items i JOIN bills b ON b.id=i.billId WHERE substr(b.date,1,7)=:m") fun monthQty(m:String):Flow<Double>
}
@Database(entities=[Product::class,Bill::class,BillItem::class],version=1)
abstract class AppDatabase:RoomDatabase(){
    abstract fun products():ProductDao
    abstract fun bills():BillDao
    companion object {
        @Volatile private var instance:AppDatabase?=null
        fun get(c:android.content.Context)=instance?: synchronized(this){
            instance?:Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"billing.db").build().also{instance=it}
        }
    }
}

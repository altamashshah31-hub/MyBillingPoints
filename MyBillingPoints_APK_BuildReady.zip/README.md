# My Billing Points — APK Build Ready

Marathi + English Android billing starter.

Features in this build:
- Dashboard monthly totals
- Multi-product bill entry
- Product master
- Bills list + delete
- Reports screen
- Local Room database
- GitHub Actions cloud APK build

The workflow installs Gradle in GitHub Actions, so Gradle Wrapper files are NOT required.

Google Drive backup, secure PIN/biometric lock, Excel/PDF generation and full edit workflow are planned production integrations.
